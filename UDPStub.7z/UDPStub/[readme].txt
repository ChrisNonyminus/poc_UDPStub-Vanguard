--UDP Stub--

To use the "Linux machine" mode (the only mode), copy the "LinuxStubLinuxSide.elf" file to somewhere on your Linux machine.
Then, in a Linux terminal where the file is, type "./LinuxStubLinuxSide.elf" without quotes.
Open UDP Stub and set the mode to "Linux machine".
Then, follow the instructions the Linux side program gives.
